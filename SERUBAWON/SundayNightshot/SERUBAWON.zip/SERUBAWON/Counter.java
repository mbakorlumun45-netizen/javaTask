//inialize loop
//loop from one to hundred
//counter to add itself
//print the sum of number from 1 to 100
public class Counter{
	public static void main(String[] args){
	
	for(int count = 1; count <= 100; count++){
		System.out.println(count + count);
	}
	}
}
